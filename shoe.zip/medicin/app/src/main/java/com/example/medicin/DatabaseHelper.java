package com.example.medicin;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "MedicalDonations.db";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_DONATIONS = "Donations";
    private static final String COLUMN_ID = "_id";
    private static final String COLUMN_FIRST_NAME = "firstName";
    private static final String COLUMN_LAST_NAME = "lastName";
    private static final String COLUMN_EMAIL = "email";
    private static final String COLUMN_STREET_ADDRESS = "streetAddress";
    private static final String COLUMN_CITY = "city";
    private static final String COLUMN_POSTAL_CODE = "postalCode";
    private static final String COLUMN_PHONE_NUMBER = "phoneNumber";
    private static final String COLUMN_EQUIPMENT = "equipment";
    private static final String COLUMN_DESCRIPTION = "description";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableQuery = "CREATE TABLE " + TABLE_DONATIONS + "(" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_FIRST_NAME + " TEXT, " +
                COLUMN_LAST_NAME + " TEXT, " +
                COLUMN_EMAIL + " TEXT, " +
                COLUMN_STREET_ADDRESS + " TEXT, " +
                COLUMN_CITY + " TEXT, " +
                COLUMN_POSTAL_CODE + " TEXT, " +
                COLUMN_PHONE_NUMBER + " TEXT, " +
                COLUMN_EQUIPMENT + " TEXT, " +
                COLUMN_DESCRIPTION + " TEXT)";
        db.execSQL(createTableQuery);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Handle database upgrades here (e.g., changing table structure)
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_DONATIONS);
        onCreate(db);
    }

    public boolean insertDonation(String firstName, String lastName, String email, String streetAddress,
                                 String city, String postalCode, String phoneNumber,
                                  String equipment, String description) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_FIRST_NAME, firstName);
        contentValues.put(COLUMN_LAST_NAME, lastName);
        contentValues.put(COLUMN_EMAIL, email);
        contentValues.put(COLUMN_STREET_ADDRESS, streetAddress);
        contentValues.put(COLUMN_CITY, city);
        contentValues.put(COLUMN_POSTAL_CODE, postalCode);
        contentValues.put(COLUMN_PHONE_NUMBER, phoneNumber);
        contentValues.put(COLUMN_EQUIPMENT, equipment);
        contentValues.put(COLUMN_DESCRIPTION, description);
        long result = db.insert(TABLE_DONATIONS, null, contentValues);
        db.close();
        return result != -1;
    }

    // Add methods to retrieve, update, and delete donation data as needed
}