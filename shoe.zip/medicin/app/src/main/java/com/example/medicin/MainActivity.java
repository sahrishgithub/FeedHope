package com.example.medicin;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.medicin.R;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private EditText firstname, lastname, email, streetaddress,  city, postalcode, phonenumber, description;
    private Spinner equipmentSpinner;
    private Button submitButton;

    private com.example.medicin.DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize database helper
        dbHelper = new com.example.medicin.DatabaseHelper(this);

        // Initialize UI elements
        firstname = findViewById(R.id.firstname);
        lastname = findViewById(R.id.lastname);
        email = findViewById(R.id.email);
        streetaddress = findViewById(R.id.streetaddress);
        city = findViewById(R.id.city);
        postalcode = findViewById(R.id.postalcode);
        phonenumber = findViewById(R.id.phonenumber);
        description= findViewById(R.id.description);
        equipmentSpinner = findViewById(R.id.equipmentSpinner);
        submitButton = findViewById(R.id.submitButton);

        // Set up submit button click listener
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get data from form
                String firstName = firstname.getText().toString();
                String lastName = lastname.getText().toString();
                String Email = email.getText().toString();
                String streetAddress = streetaddress.getText().toString();
                String City = city.getText().toString();
                String postalCode = postalcode.getText().toString();
                String phoneNumber = phonenumber.getText().toString();
                String equipment = equipmentSpinner.getSelectedItem().toString();
                String Description = description.getText().toString();

                // Validate data
                if (firstName.isEmpty() || lastName.isEmpty() || Email.isEmpty() ||
                        streetAddress.isEmpty() || City.isEmpty() || postalCode.isEmpty() ||
                        phoneNumber.isEmpty() || equipment.isEmpty() || Description.isEmpty())
                {
                    Toast.makeText(MainActivity.this, "Please fill out all fields.", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Store data in database
                boolean success = dbHelper.insertDonation(firstName, lastName, Email, streetAddress,
                        City, postalCode, phoneNumber, equipment, Description);

                if (success) {
                    Toast.makeText(MainActivity.this, "Donation submitted successfully.", Toast.LENGTH_SHORT).show();
                    clearForm();
                } else {
                    Toast.makeText(MainActivity.this, "Error submitting donation.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // Method to clear the form after submission
    private void clearForm() {
        firstname.setText("");
        lastname.setText("");
        email.setText("");
        streetaddress.setText("");
        city.setText("");
        postalcode.setText("");
        phonenumber.setText("");
        equipmentSpinner.setSelection(0);
        description.setText("");
    }

}