package com.example.clothform;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper{
    private static final String DATABASE_NAME = "clothdonation.db";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_DONATIONS = "Donations";
    private static final String COLUMN_FIRST_NAME = "firstNameEditText";
    private static final String COLUMN_LAST_NAME = "lastNameEditText";
    private static final String COLUMN_EMAIL_EDIT_TEXT = "emailEditText";
    private static final String COLUMN_PHONE_NUMBER_EDIT_TEXT = "phoneNumberEditText";
    private static final String COLUMN_ERROR_TEXT_VIEW= "errorTextView";
    private static final String COLUMN_SPINNER = "spinner";
    private static final String COLUMN_SPINNER1 = "spinner1";
    private static final String COLUMN_CHECK_BOX1 = "checkBox1";
    private static final String COLUMN_CHECK_BOX2 = "checkBox2";
    private static final String COLUMN_CHECK_BOX3 = "checkBox3";
    private static final String COLUMN_CHECK_BOX4 = "checkBox4";
    private static final String COLUMN_CHECK_BOX5 = "checkBox5";
    private static final String COLUMN_CHECK_BOX6 = "checkBox6";
    private static final String COLUMN_CHECK_BOX7 = "checkBox7";
    private static final String COLUMN_CHECK_BOX8 = "checkBox8";
    private static final String COLUMN_CHECK_BOX9 = "checkBox9";
    private static final String COLUMN_CHECK_BOX10 = "checkBox10";
    private static final String COLUMN_SPINNER2 = "spinner2";
    private static final String COLUMN_SPINNER3 = "spinner3";
    private static final String COLUMN_SPINNER4 = "spinner4";
    private static final String COLUMN_BUTTON = "button";
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableQuery = "CREATE TABLE " + TABLE_DONATIONS + "(" +
                COLUMN_PHONE_NUMBER_EDIT_TEXT + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_FIRST_NAME + " TEXT, " +
                COLUMN_LAST_NAME + " TEXT, " +
                COLUMN_EMAIL_EDIT_TEXT + " TEXT, " +
                COLUMN_ERROR_TEXT_VIEW + " TEXT, " +
                COLUMN_SPINNER + " TEXT, " +
                COLUMN_SPINNER1 + " TEXT, " +
                COLUMN_CHECK_BOX1 + " TEXT,"+
                COLUMN_CHECK_BOX2 + " TEXT,"+
                COLUMN_CHECK_BOX3 + " TEXT,"+
                COLUMN_CHECK_BOX4 + " TEXT,"+
                COLUMN_CHECK_BOX5 + " TEXT,"+
                COLUMN_CHECK_BOX6 + " TEXT,"+
                COLUMN_CHECK_BOX7 + " TEXT,"+
                COLUMN_CHECK_BOX8 + " TEXT,"+
                COLUMN_CHECK_BOX9 + " TEXT,"+
                COLUMN_CHECK_BOX10 + " TEXT,"+
                COLUMN_SPINNER2 + " TEXT,"+
                COLUMN_SPINNER3 + " TEXT,"+
                COLUMN_SPINNER4 + " TEXT,"+
                COLUMN_BUTTON + "TEXT)";
        db.execSQL(createTableQuery);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Handle database upgrades here (e.g., changing table structure)
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_DONATIONS);
        onCreate(db);
    }
    public boolean insertDonation(String phone, String firstname,String lastName, String email, String errortext,
                                  String spinner, String spinner1, String checkbox2,String checkbox3,String checkbox4,String checkbox5
    ,String checkbox1,String checkbox6,String checkbox7,String checkbox8,String checkbox9,String checkbox10,String spinner2,String spinner3,String spinner4,
    String btn) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_PHONE_NUMBER_EDIT_TEXT, phone);
        contentValues.put(COLUMN_FIRST_NAME, firstname);
        contentValues.put(COLUMN_LAST_NAME, lastName);
        contentValues.put(COLUMN_EMAIL_EDIT_TEXT, email);
        contentValues.put(COLUMN_ERROR_TEXT_VIEW, errortext);
        contentValues.put(COLUMN_SPINNER, spinner);
        contentValues.put(COLUMN_SPINNER1, spinner1);
        contentValues.put(COLUMN_CHECK_BOX1, checkbox1);
        contentValues.put(COLUMN_CHECK_BOX2, checkbox2);
        contentValues.put(COLUMN_CHECK_BOX3, checkbox3);
        contentValues.put(COLUMN_CHECK_BOX4, checkbox4);
        contentValues.put(COLUMN_CHECK_BOX5, checkbox5);
        contentValues.put(COLUMN_CHECK_BOX6, checkbox6);
        contentValues.put(COLUMN_CHECK_BOX7, checkbox7);
        contentValues.put(COLUMN_CHECK_BOX8, checkbox8);
        contentValues.put(COLUMN_CHECK_BOX9, checkbox9);
        contentValues.put(COLUMN_CHECK_BOX10, checkbox10);
        contentValues.put(COLUMN_SPINNER1, spinner2);
        contentValues.put(COLUMN_SPINNER1, spinner3);
        contentValues.put(COLUMN_SPINNER1, spinner4);
        contentValues.put(COLUMN_BUTTON, btn);
        long result = db.insert(TABLE_DONATIONS, null, contentValues);
        db.close();
        return result != -1;
    }

    public void insertData(String firstName, String lastName, String email, String phoneNumber, String spinnerValue, String spinner1Value, String spinner2Value, String spinner3Value, String spinner4Value, boolean checkBox1Value, boolean checkBox2Value, boolean checkBox3Value, boolean checkBox4Value, boolean checkBox5Value, boolean checkBox6Value, boolean checkBox7Value, boolean checkBox8Value, boolean checkBox9Value, boolean checkBox10Value) {
    }
}
