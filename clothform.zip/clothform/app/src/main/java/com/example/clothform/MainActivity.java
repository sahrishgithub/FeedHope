package com.example.clothform;

import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.AdapterView;
import android.widget.Toast;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {


    //for access image from gallery
    private static final int PICK_IMAGE_REQUEST = 1;
    private TextView titleTextView;
    private Button browseButton;

    private EditText firstNameEditText;
    private EditText lastNameEditText;
    private EditText emailEditText;
    private EditText phoneNumberEditText;
    private TextView errorTextView;
    Spinner spinner, spinner1, spinner2, spinner3, spinner4;
    CheckBox checkBox1, checkBox2, checkBox3, checkBox4, checkBox5, checkBox6, checkBox7, checkBox8, checkBox9, checkBox10;
    private Button button;
    // Create an array of options for the Spinner
    String[] options = {"Please Select", "Brand New", "Very Good Condition", "Good Condition", "Average Condition", "Bad Condition"};
    String[] options1 = {"Please Select", "Wedding Dress", "Formal Dress", "Evening Dress", "Summer Dress", "Winter Dress"};
    String[] options2 = {"Please Select", "Red", "Brown", "Green", "Pink", "Black", "Cream", "White", "Gray"};
    String[] options3 = {"Please Select", "Size 4", "Size 6", "Size 8", "Size 10", "Size 12", "Size 14", "Size 16", "Size 18", "Size 20", "Size 25", "Size 30", "Child 0-5", "Child 5-16", "Small", "Medium", "Large", "XL", "XXL", "XXXL", "XXXXL", "Unknown", "Other"};
    String[] options4 = {"0-2", "2-5", "5-9", "9-12", "12+"};

    private com.example.clothform.DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Initialize database helper
        dbHelper = new com.example.clothform.DatabaseHelper(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        titleTextView.setText("Please upload the photos of the dress.");
        browseButton.setText("Browse Files");

        browseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get values from EditTexts
                String firstName = firstNameEditText.getText().toString();
                String lastName = lastNameEditText.getText().toString();
                String email = emailEditText.getText().toString();
                String phoneNumber = phoneNumberEditText.getText().toString();

                // Get values from Spinners
                String spinnerValue = spinner.getSelectedItem().toString();
                String spinner1Value = spinner1.getSelectedItem().toString();
                String spinner2Value = spinner2.getSelectedItem().toString();
                String spinner3Value = spinner3.getSelectedItem().toString();
                String spinner4Value = spinner4.getSelectedItem().toString();

                // Get values from CheckBoxes
                boolean checkBox1Value = checkBox1.isChecked();
                boolean checkBox2Value = checkBox2.isChecked();
                boolean checkBox3Value = checkBox3.isChecked();
                boolean checkBox4Value = checkBox4.isChecked();
                boolean checkBox5Value = checkBox5.isChecked();
                boolean checkBox6Value = checkBox6.isChecked();
                boolean checkBox7Value = checkBox7.isChecked();
                boolean checkBox8Value = checkBox8.isChecked();
                boolean checkBox9Value = checkBox9.isChecked();
                boolean checkBox10Value = checkBox10.isChecked();

                // Save data to database
                saveDataToDatabase(firstName, lastName, email, phoneNumber, spinnerValue, spinner1Value, spinner2Value, spinner3Value, spinner4Value, checkBox1Value, checkBox2Value, checkBox3Value, checkBox4Value, checkBox5Value, checkBox6Value, checkBox7Value, checkBox8Value, checkBox9Value, checkBox10Value);
            }

            private void saveDataToDatabase(String firstName, String lastName, String email, String phoneNumber, String spinnerValue, String spinner1Value, String spinner2Value, String spinner3Value, String spinner4Value, boolean checkBox1Value, boolean checkBox2Value, boolean checkBox3Value, boolean checkBox4Value, boolean checkBox5Value, boolean checkBox6Value, boolean checkBox7Value, boolean checkBox8Value, boolean checkBox9Value, boolean checkBox10Value) {
                // Create a new database helper
                DatabaseHelper dbHelper = new DatabaseHelper(getApplicationContext());

                // Insert data into database
                dbHelper.insertData(firstName, lastName, email, phoneNumber, spinnerValue, spinner1Value, spinner2Value, spinner3Value, spinner4Value, checkBox1Value, checkBox2Value, checkBox3Value, checkBox4Value, checkBox5Value, checkBox6Value, checkBox7Value, checkBox8Value, checkBox9Value, checkBox10Value);
            }
        });


        // Find the Spinner in the layout
        spinner = findViewById(R.id.spinner);
        spinner1 = findViewById(R.id.spinner1);
        spinner2 = findViewById(R.id.spinner2);
        spinner3 = findViewById(R.id.spinner3);
        spinner4 = findViewById(R.id.spinner4);
        checkBox1 = findViewById(R.id.checkBox1);
        checkBox2 = findViewById(R.id.checkBox2);
        checkBox3 = findViewById(R.id.checkBox3);
        checkBox4 = findViewById(R.id.checkBox4);
        checkBox5 = findViewById(R.id.checkBox5);
        checkBox6 = findViewById(R.id.checkBox6);
        checkBox7 = findViewById(R.id.checkBox7);
        checkBox8 = findViewById(R.id.checkBox8);
        checkBox9 = findViewById(R.id.checkBox9);
        checkBox10 = findViewById(R.id.checkBox10);


        // Set OnCheckedChangeListener for each CheckBox
        checkBox1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    checkBox2.setChecked(false);
                    checkBox3.setChecked(false);
                    checkBox4.setChecked(false);
                    checkBox5.setChecked(false);
                    checkBox6.setChecked(false);
                    checkBox7.setChecked(false);
                    checkBox8.setChecked(false);
                    checkBox9.setChecked(false);
                    checkBox10.setChecked(false);

                }
            }
        });
        // Set OnCheckedChangeListener for each CheckBox
        checkBox2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    checkBox1.setChecked(false);
                    checkBox3.setChecked(false);
                    checkBox4.setChecked(false);
                    checkBox5.setChecked(false);
                    checkBox6.setChecked(false);
                    checkBox7.setChecked(false);
                    checkBox8.setChecked(false);
                    checkBox9.setChecked(false);
                    checkBox10.setChecked(false);

                }
            }
        });
        // Set OnCheckedChangeListener for each CheckBox
        checkBox3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    checkBox1.setChecked(false);
                    checkBox2.setChecked(false);
                    checkBox4.setChecked(false);
                    checkBox5.setChecked(false);
                    checkBox6.setChecked(false);
                    checkBox7.setChecked(false);
                    checkBox8.setChecked(false);
                    checkBox9.setChecked(false);
                    checkBox10.setChecked(false);

                }
            }
        });
        // Set OnCheckedChangeListener for each CheckBox
        checkBox4.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    checkBox1.setChecked(false);
                    checkBox2.setChecked(false);
                    checkBox3.setChecked(false);
                    checkBox5.setChecked(false);
                    checkBox6.setChecked(false);
                    checkBox7.setChecked(false);
                    checkBox8.setChecked(false);
                    checkBox9.setChecked(false);
                    checkBox10.setChecked(false);

                }
            }
        });
        // Set OnCheckedChangeListener for each CheckBox
        checkBox5.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    checkBox1.setChecked(false);
                    checkBox3.setChecked(false);
                    checkBox4.setChecked(false);
                    checkBox2.setChecked(false);
                    checkBox6.setChecked(false);
                    checkBox7.setChecked(false);
                    checkBox8.setChecked(false);
                    checkBox9.setChecked(false);
                    checkBox10.setChecked(false);

                }
            }
        });
        // Set OnCheckedChangeListener for each CheckBox
        checkBox6.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    checkBox1.setChecked(false);
                    checkBox3.setChecked(false);
                    checkBox4.setChecked(false);
                    checkBox5.setChecked(false);
                    checkBox2.setChecked(false);
                    checkBox7.setChecked(false);
                    checkBox8.setChecked(false);
                    checkBox9.setChecked(false);
                    checkBox10.setChecked(false);

                }
            }
        });
        // Set OnCheckedChangeListener for each CheckBox
        checkBox7.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    checkBox1.setChecked(false);
                    checkBox3.setChecked(false);
                    checkBox4.setChecked(false);
                    checkBox5.setChecked(false);
                    checkBox6.setChecked(false);
                    checkBox2.setChecked(false);
                    checkBox8.setChecked(false);
                    checkBox9.setChecked(false);
                    checkBox10.setChecked(false);

                }
            }
        });
        // Set OnCheckedChangeListener for each CheckBox
        checkBox8.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    checkBox1.setChecked(false);
                    checkBox3.setChecked(false);
                    checkBox4.setChecked(false);
                    checkBox5.setChecked(false);
                    checkBox6.setChecked(false);
                    checkBox7.setChecked(false);
                    checkBox2.setChecked(false);
                    checkBox9.setChecked(false);
                    checkBox10.setChecked(false);

                }
            }
        });
        // Set OnCheckedChangeListener for each CheckBox
        checkBox9.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    checkBox1.setChecked(false);
                    checkBox3.setChecked(false);
                    checkBox4.setChecked(false);
                    checkBox5.setChecked(false);
                    checkBox6.setChecked(false);
                    checkBox7.setChecked(false);
                    checkBox8.setChecked(false);
                    checkBox2.setChecked(false);
                    checkBox10.setChecked(false);

                }
            }
        });
        // Set OnCheckedChangeListener for each CheckBox
        checkBox10.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    checkBox1.setChecked(false);
                    checkBox3.setChecked(false);
                    checkBox4.setChecked(false);
                    checkBox5.setChecked(false);
                    checkBox6.setChecked(false);
                    checkBox7.setChecked(false);
                    checkBox8.setChecked(false);
                    checkBox9.setChecked(false);
                    checkBox2.setChecked(false);

                }
            }
        });


        // Create an ArrayAdapter for the Spinner
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, options);
        // Set the adapter for the Spinner
        spinner.setAdapter(adapter);
        // Set an OnItemSelectedListener for the Spinner
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // Display a toast message when an option is selected
                Toast.makeText(getApplicationContext(), "You selected: " + options[position], Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing
            }
        });


        // Create an ArrayAdapter for the Spinner
        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, options1);

        // Set the adapter for the Spinner
        spinner1.setAdapter(adapter1);

        // Set an OnItemSelectedListener for the Spinner
        spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // Display a toast message when an option is selected
                Toast.makeText(getApplicationContext(), "You selected: " + options1[position], Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing
            }
        });
        // Create an ArrayAdapter for the Spinner
        ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, options2);

        // Set the adapter for the Spinner
        spinner2.setAdapter(adapter2);

        // Set an OnItemSelectedListener for the Spinner
        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // Display a toast message when an option is selected
                Toast.makeText(getApplicationContext(), "You selected: " + options2[position], Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing
            }
        });
        // Create an ArrayAdapter for the Spinner
        ArrayAdapter<String> adapter3 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, options3);

        // Set the adapter for the Spinner
        spinner3.setAdapter(adapter3);

        // Set an OnItemSelectedListener for the Spinner
        spinner3.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // Display a toast message when an option is selected
                Toast.makeText(getApplicationContext(), "You selected: " + options3[position], Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing
            }
        });
        // Create an ArrayAdapter for the Spinner
        ArrayAdapter<String> adapter4 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, options4);

        // Set the adapter for the Spinner
        spinner4.setAdapter(adapter4);

        // Set an OnItemSelectedListener for the Spinner
        spinner4.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // Display a toast message when an option is selected
                Toast.makeText(getApplicationContext(), "You selected: " + options4[position], Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing
            }
        });

        firstNameEditText = findViewById(R.id.firstNameEditText);
        lastNameEditText = findViewById(R.id.lastNameEditText);
        emailEditText = findViewById(R.id.emailEditText);
        phoneNumberEditText = findViewById(R.id.phoneNumberEditText);
        errorTextView = findViewById(R.id.errorTextView);
    }

    public void validateForm() {
        // Get the input values from the EditTexts.
        String firstName = firstNameEditText.getText().toString();
        String lastName = lastNameEditText.getText().toString();
        String email = emailEditText.getText().toString();
        String phoneNumber = phoneNumberEditText.getText().toString();
        // Validate the inputs.
        boolean isValid = true;
        if (firstName.isEmpty()) {
            isValid = false;
            errorTextView.setText("Please enter your first name.");
        } else if (lastName.isEmpty()) {
            isValid = false;
            errorTextView.setText("Please enter your last name.");
        } else if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            isValid = false;
            errorTextView.setText("Please enter a valid email address.");
        } else if (!phoneNumber.matches("\\d{3}-\\d{3}-\\d{4}")) {
            isValid = false;
            errorTextView.setText("Please enter a valid phone number (XXX-XXX-XXXX).");
        }
    }
}